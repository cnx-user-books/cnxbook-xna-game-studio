/*Project XNA0132ProjA
********************************************************/
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace XNA0132ProjA {

  public class Game1 : Microsoft.Xna.Framework.Game {
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;
    SpriteFont Font1;
    Vector2 FontPos;
    //-------------------------------------------------//

    protected override void LoadContent() {
      spriteBatch = new SpriteBatch(GraphicsDevice);

      //Create a new SpriteFont object.
      Font1 = Content.Load<SpriteFont>("Lindsey");

      //Create a new Vector2 object to center the text
      // in the game window.
      FontPos = new Vector2(
            graphics.GraphicsDevice.Viewport.Width / 2,
            graphics.GraphicsDevice.Viewport.Height / 2);
    }//end LoadContent method
    //-------------------------------------------------//

    protected override void Draw(GameTime gameTime) {
      GraphicsDevice.Clear(Color.CornflowerBlue);

      spriteBatch.Begin();

      // Draw Hello World
      string output = "Lindsey Font";

      // Find the center of the string
      Vector2 FontOrigin = 
                         Font1.MeasureString(output) / 2;
      //Draw the string with the FontOrigin at the 
      // position specified by FontPos.
      spriteBatch.DrawString(
          Font1,//font to use
          output,//output text
          FontPos,//position re upper left corner
          Color.LightGreen,//color of text
          -45,//rotation of text
          FontOrigin,//place this at FontPos
          2.5f,//scale
          SpriteEffects.None,
          0.5f);//z-order layer

      spriteBatch.End();

      base.Draw(gameTime);
    }//end Draw method
    //-------------------------------------------------//

    protected override void Update(GameTime gameTime) {
      // Allows the game to exit
      if(GamePad.GetState(PlayerIndex.One).
                     Buttons.Back == ButtonState.Pressed)
        this.Exit();

      //No special update code required.

      base.Update(gameTime);
    }//end Update method
    //-------------------------------------------------//

    protected override void Initialize() {
      //Not needed
      base.Initialize();
    }//end Initialize
    //-------------------------------------------------//

    public Game1() {//Typical constructor
      graphics = new GraphicsDeviceManager(this);
      Content.RootDirectory = "Content";
    }//end constructor
    //-------------------------------------------------//

    protected override void UnloadContent() {
      //Not needed
    }//end UnloadContent
    //-------------------------------------------------//
  }//end class
}//end namespace
