﻿/*Project Props01
Copyright 2009, R.G.Baldwin

This program is designed to explore and explain the use 
of encapsulation and properties in C#.

Program output is:
text: Quit
color: Red
color: Bad color
height: 20
double height: 40
height: 0
*********************************************************/

using System;

namespace Props01
{
    class Props01a
    {
        static void Main(string[] args)
        {
            TargetClass obj = new TargetClass();

            //Access a public instance variable
            obj.text = "Quit";
            Console.WriteLine("text: " + obj.text);

            //Call public accessor methods 
            obj.setColor("Red");
            Console.WriteLine("color: " + obj.getColor());

            //Call public accessor methods again with an
            // invalid input value.
            obj.setColor("Green");
            Console.WriteLine("color: " + obj.getColor());

            //Set and get a property
            obj.height = 20;
            Console.WriteLine("height: " + obj.height);

            //Call manipulator method and display results.
            obj.doubleHeight();
            Console.WriteLine("double height: " + obj.height);

            //Set and get the property again with an invalid
            // input value.
            obj.height = 100;
            Console.WriteLine("height: " + obj.height);

            //Pause until user presses any key.
            Console.ReadKey();
        }//end Main

    }//end class Props01a
    //====================================================//

    public class TargetClass
    {
        //A public instance variable - not good practice
        public string text;

        //This would be a property named color in Java, but
        // not in C#
        private string colorData = "";
        public void setColor(string data)
        {
            //Validating code
            if (data.Equals("Red") || data.Equals("Blue"))
            {
                //Accept incoming data value
                colorData = data;
            }
            else
            {
                //Reject incoming data value
                colorData = "Bad color";
            }//end if-else
        }//end setColor
        //--------------------------------------------------//

        public string getColor()
        {
            return colorData;
        }//end getColor
        //--------------------------------------------------//

        //This is a C# property named height
        private int heightData;
        public int height
        {
            get
            {
                return heightData;
            }//end get
            set
            {
                //Validating code
                if (value < 84)
                {
                    heightData = value;
                }
                else
                {
                    heightData = 0;
                }//end else
            }//end set
        }//end height property
        //--------------------------------------------------//

        //This is a manipulator method
        public void doubleHeight()
        {
            heightData *= 2;
        }//end doubleHeight
        //--------------------------------------------------//

    }//end TargetClass
}//end namespace
