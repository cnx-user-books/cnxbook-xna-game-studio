/*Project XNA0120Proj
 * 12/27/09 R.G.Baldwin
 *******************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.Diagnostics;//to access Debug

namespace XNA0120Proj {

  public class Game1 : Microsoft.Xna.Framework.Game {
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;

    public Game1() {
      graphics = new GraphicsDeviceManager(this);
      Content.RootDirectory = "Content";
    }// end constructor

    protected override void Initialize() {
      //No initialization needed
      base.Initialize();
    }//end Initialize

    //Declare two variables
    Texture2D myTexture;
    Vector2 spritePosition = new Vector2(10.0f,15.0f);

    protected override void LoadContent() {
      //Create a new SpriteBatch, which can be used to
      // draw textures.
      spriteBatch = new SpriteBatch(GraphicsDevice);
      //Load the image
      myTexture = Content.Load<Texture2D>(
                                         "gorightarrow");

      //Debug code for illustration purposes.
      Debug.WriteLine(myTexture.Width);
      Debug.WriteLine(myTexture.Height);
      Debug.WriteLine(Window.ClientBounds.Width);
      Debug.WriteLine(Window.ClientBounds.Height);
      Debug.WriteLine(IsFixedTimeStep);
      Debug.WriteLine(TargetElapsedTime);
    }//end LoadContent

    protected override void UnloadContent() {
      //No unload code needed.
    }//end UnloadContent

    //Specify the distance in pixels that the sprite
    // will move during each iteration.
    int stepsX = 5;
    int stepsY = 3;
    protected override void Update(GameTime gameTime) {
      // Allows the game to exit
      if(GamePad.GetState(PlayerIndex.One).Buttons.Back
                                  == ButtonState.Pressed)
        this.Exit();
      //New code begins here.

      //Test to determine if the sprite moves out of the
      // game window on the right or the left.
      if(((spritePosition.X + myTexture.Width) > 
                            Window.ClientBounds.Width) ||
                                 (spritePosition.X < 0)){
        stepsX *= -1;//Out of bounds, reverse diection
      }//end if

      //Test to determine if the sprite moves out of the
      // game window on the bottom or the top.
      if(((spritePosition.Y + myTexture.Height) > 
                           Window.ClientBounds.Height) ||
                                (spritePosition.Y < 0)) {
        stepsY *= -1;//Out of bounds, reverse direction
      }//end if
      spritePosition.X += stepsX;//move horizontal
      spritePosition.Y += stepsY;//move vertical

      //The following statement is always required.
      base.Update(gameTime);
    }//end Update

    protected override void Draw(GameTime gameTime) {
      GraphicsDevice.Clear(Color.CornflowerBlue);

      // Draw the sprite.
      spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
      spriteBatch.Draw(
                   myTexture,spritePosition,Color.White);
      spriteBatch.End();

      //This statement is always required.
      base.Draw(gameTime);
    }//end Draw method
  }//End class
}//End namespace
