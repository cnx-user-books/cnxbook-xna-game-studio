﻿/*Project Polymorph03
Copyright 2009, R.G.Baldwin

This program illustrates downcasting
and polymorphic behavior

Program output is:
  
m in class B
m in class B
m in class A
*********************************************************/
using System;

class A
{
    public virtual void m()
    {
        Console.WriteLine("m in class A");
    }//end method m()
}//end class A
//======================================================//

class B : A
{
    public override void m()
    {
        Console.WriteLine("m in class B");
    }//end method m()
}//end class B
//======================================================//

public class Polymorph03
{
    public static void Main()
    {
        Object var = new B();
        //Following will compile and run
        ((B)var).m();
        //Following will also compile 
        // and run due to polymorphic
        // behavior.
        ((A)var).m();
        //Following will not compile
        //var.m();
        //Instantiate obj of class A
        var = new A();
        //Call the method on it
        ((A)var).m();

        // Pause until the user presses any key.
        Console.ReadKey();
    }//end Main
}//end class Polymorph03
