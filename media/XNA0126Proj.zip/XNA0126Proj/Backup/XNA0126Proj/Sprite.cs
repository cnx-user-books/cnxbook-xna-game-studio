﻿/*Project XNA0126Proj
 * This file defines a very simple version of a Sprite
 * class from which multiple Sprite objects can be
 * instantiated, loaded with an image, and drawn.
 * The position variable can be accessed by the user
 * to control the position at which the sprite is drawn.
 *******************************************************/

using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace XNA0126Proj {
  class Sprite {
    private Texture2D texture;
    private Vector2 position = new Vector2(0,0);
    //-------------------------------------------------//

    public Vector2 Position {
      get {
        return position;
      }
      set {
        position = value;
      }//end set
    }//end Position property accessor
    //-------------------------------------------------//

    //This constructor makes it possible to instantiate
    // a sprite without assigning an image to the sprite.
    public Sprite() {//constructor
    }//end noarg constructor
    //-------------------------------------------------//

    //This constructor makes it possible to assign an
    // image to the sprite when it is instantiated.
    public Sprite(String assetName,
                  ContentManager contentManager) {
      texture = contentManager.Load<Texture2D>(assetName);
    }//end constructor
    //-------------------------------------------------//

    //This method makes it possible to assign a new image
    // to the sprite.
    public void SetImage(String assetName,
                         ContentManager contentManager) {
      texture = contentManager.Load<Texture2D>(assetName);
    }//end SetImage
    //-------------------------------------------------//

    public void Draw(SpriteBatch spriteBatch) {
      //Call the simplest available version of
      // SpriteBatch.Draw
      spriteBatch.Draw(texture,position,Color.White);
    }//end Draw method
    //-------------------------------------------------//
  }//end class
}//end namespace

