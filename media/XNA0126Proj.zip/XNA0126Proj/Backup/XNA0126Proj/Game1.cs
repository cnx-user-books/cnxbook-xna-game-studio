/*Project XNA0126Proj
 * This project demonstrates how to design and use a very
 * simple version of a Sprite class.
 * 
 * One Sprite object is instantiated in the LoadContent
 * method. The object's reference is saved in a generic
 * List object.
 * 
 * Twenty-three more Sprite objects are instantiated 
 * while the game loop is running. A new object is
 * instantiated every 8th iteration of the game loop 
 * until 24 objects have been instantiated. Their 
 * references are saved in a generic List object.
 * 
 * An image of a blueball is stored in 12 of the objects
 * and an image of a redball is stored in the other 12
 * objects.
 * 
 * The Sprite objects are drawn in a diagonal line in 
 * the game window. The line of Sprite objects moves 
 * across the game window from upper left to lower right.
 * The Sprite objects stop moving when they reach the
 * bottom right corner of the game window.
 * 
 * When the objects stop moving, the image in the 
 * topmost Sprite object is changed from a blueball to a 
 * greenball.
 * *****************************************************/
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using XNA0126Proj;

namespace XNA0126Proj {

  public class Game1 : Microsoft.Xna.Framework.Game {
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;

    //References to the Sprite objects are stored in this
    // List object.
    List<Sprite> sprites = new List<Sprite>();

    int maxSprites = 24;//Max number of sprites.
    int frameCnt = 0;//Game loop frame counter

    //This is the limit on the number of frames in which
    // the sprites are moved.
    int moveLim = 200;
    //-------------------------------------------------//

    public Game1() {//constructor
      graphics = new GraphicsDeviceManager(this);
      Content.RootDirectory = "Content";

      //Set the size of the game window.
      graphics.PreferredBackBufferWidth = 450;
      graphics.PreferredBackBufferHeight = 450;
    }//end constructor
    //-------------------------------------------------//

    protected override void Initialize() {
      //No initialization required.
      base.Initialize();
    }//end Initialize
    //-------------------------------------------------//

    protected override void LoadContent() {
      spriteBatch = new SpriteBatch(GraphicsDevice);

      //Create the first sprite in the LoadContent
      // method using the noarg constructor.
      sprites.Add(new Sprite());
      //Assign an image to the sprite.
      sprites[0].SetImage("blueball",Content);
      //More ontent is loaded in the Update method.
    }//end LoadContent
    //-------------------------------------------------//

    protected override void UnloadContent() {
      //No content unload required.
    }//end unloadContent
    //-------------------------------------------------//

    protected override void Update(GameTime gameTime) {

      //Create remaining sprites in the Update method to
      // simulate a game in which sprites come and go as
      // the game progresses.
      if(sprites.Count < (maxSprites)) {
        
        if(frameCnt % 8 == 0) {
          
          //Instantiate a new sprite every 8th frame.
          if((sprites.Count) % 2 == 0) {
            //Even numbered sprites
            sprites.Add(new Sprite("blueball",Content));
          }
          else {
            //Odd numbered sprites
            sprites.Add(new Sprite("redball",Content));
          }//end else 
        }//end if on frameCnt
      }//end if on sprites.Count

      //Make all the sprites move.
      if(frameCnt < moveLim) {
        for(int cnt = 0;cnt < sprites.Count;cnt++) {
          sprites[cnt].Position = new Vector2(
                10 * cnt + frameCnt,10 * cnt + frameCnt);
        }//end for loop
      }//end if

      //Change the image on the first sprite at the end
      // of the run. Could be used, for example to 
      // change a sprite's image to a fireball in the
      // event of a collision.
      if(frameCnt == moveLim) {
        sprites[0].SetImage("greenball",Content);
      }//end if

      //Keep track of the count of the first moveLim
      // iterations of the game loop.
      if(frameCnt < moveLim) {
        frameCnt++;
      }//end if

      base.Update(gameTime);
    }//end Update method
    //-------------------------------------------------//

    protected override void Draw(GameTime gameTime) {
      GraphicsDevice.Clear(Color.CornflowerBlue);

      spriteBatch.Begin();

      //Draw all sprites.
      for(int cnt = 0;cnt < sprites.Count;cnt++) {
        sprites[cnt].Draw(spriteBatch);
      }//end for loop

      spriteBatch.End();

      base.Draw(gameTime);
    }//end Draw method
    //-------------------------------------------------//
  }//end class
}//end namespace

