﻿/*Project Airship01
 * Illustrates inheritance
 * ******************************************************/

using System;

namespace Airship01
{

    //Define a class to exercise the Balloon class and the
    // Airplane class.
    class Driver
    {
        static void Main(string[] args)
        {
            Balloon balloon = new Balloon();
            balloon.range = 5;
            balloon.altitude = 500;
            balloon.passengerCapacity = 5;
            balloon.liftMedia = "Hot Air";

            Console.WriteLine("Balloon");
            Console.WriteLine(
                         "range = " + balloon.range + " miles");
            Console.WriteLine(
                    "altitude = " + balloon.altitude + " feet");
            Console.WriteLine("passenger capacity = "
                                   + balloon.passengerCapacity);
            Console.WriteLine("lift media = "
                                           + balloon.liftMedia);

            Airplane airplane = new Airplane();
            airplane.range = 5000;
            airplane.altitude = 35000;
            airplane.cargoCapacity = 20000;
            airplane.engineType = "jet";

            Console.WriteLine("");//blank line
            Console.WriteLine("Airplane");
            Console.WriteLine(
                        "range = " + airplane.range + " miles");
            Console.WriteLine(
                   "altitude = " + airplane.altitude + " feet");
            Console.WriteLine("cargo capacity = "
                          + airplane.cargoCapacity + " pounds");
            Console.WriteLine("engine type = "
                                         + airplane.engineType);

            //Pause and wait for the user to press any key.
            Console.ReadKey();
        }//end Main
    }//end class Driver
    //====================================================//

    //Define common properties in the base class.
    class Airship
    {
        private int rangeData = 0;
        private int altitudeData = 0;

        public int range
        {
            get
            {
                return rangeData;
            }//end get
            set
            {
                rangeData = value;
            }//end set
        }//end range property

        public int altitude
        {
            get
            {
                return altitudeData;
            }//end get
            set
            {
                altitudeData = value;
            }//end set
        }//end altitude property

    }//end class Airship
    //====================================================//

    //Define unique properties in the subclass.
    class Balloon : Airship
    {
        private int passengerCapacityData;
        private String liftMediaData;

        public int passengerCapacity
        {
            get
            {
                return passengerCapacityData;
            }//end get
            set
            {
                passengerCapacityData = value;
            }//end set
        }//end passengerCapacity property

        public String liftMedia
        {
            get
            {
                return liftMediaData;
            }//end get
            set
            {
                liftMediaData = value;
            }//end set
        }//end liftMedia property
    }//end Balloon class
    //====================================================//

    //Define unique properties in the subclass.
    class Airplane : Airship
    {
        private int cargoCapacityData;
        private String engineTypeData;

        public int cargoCapacity
        {
            get
            {
                return cargoCapacityData;
            }//end get
            set
            {
                cargoCapacityData = value;
            }//end set
        }//end cargoCapacity property

        public String engineType
        {
            get
            {
                return engineTypeData;
            }//end get
            set
            {
                engineTypeData = value;
            }//end set
        }//end engineType property
    }//end Airplane class
    //====================================================//
}//end namespace Airship01
