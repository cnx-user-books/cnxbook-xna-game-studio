/*Project XNA0128Proj
 * This project demonstrates how to integrate space 
 * rocks, power pills, and ufos in a program using
 * objects of a Sprite class. This could be the 
 * beginnings of a space game.
 * *****************************************************/
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using XNA0128Proj;

namespace XNA0128Proj
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //Use the following values to set the size of the
        // client area of the game window. The actual window
        // with its frame is somewhat larger depending on
        // the OS display options. On my machine with its
        // current display options, these dimensions
        // produce a 1024x768 game window.
        int windowWidth = 1017;
        int windowHeight = 738;

        //This is the length of the greatest distance in
        // pixels that any sprite will move in a single
        // frame of the game loop.
        double maxVectorLength = 5.0;

        //References to the space rocks are stored in this
        // List object.
        List<Sprite> rocks = new List<Sprite>();
        int numRocks = 24;//Number of rocks.
        //The following value should never exceed 60 moves
        // per second unless the default frame rate is also
        // increased to more than 60 frames per second.
        double maxRockSpeed = 50;//frames per second

        //References to the power pills are stored in 
        // this List.
        List<Sprite> pills = new List<Sprite>();
        int numPills = 12;//Number of pills.
        double maxPillSpeed = 40;//moves per second

        //References to the UFOs are stored in this List.
        List<Sprite> ufos = new List<Sprite>();
        int numUfos = 6;//Max number of ufos
        double maxUfoSpeed = 30;

        //Random number generator. It is best to use a single
        // object of the Random class to avoid the 
        // possibility of using different streams that
        // produce the same sequence of values.
        //Note that the random.NextDouble() method produces
        // a pseudo-random value where the sequence of values
        // is uniformly distributed between 0.0 and 1.0.
        Random random = new Random();
        //-------------------------------------------------//

        public Game1()
        {//constructor
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            //Set the size of the game window.
            graphics.PreferredBackBufferWidth = windowWidth;
            graphics.PreferredBackBufferHeight = windowHeight;
        }//end constructor
        //-------------------------------------------------//

        protected override void Initialize()
        {
            //No initialization required.
            base.Initialize();
        }//end Initialize
        //-------------------------------------------------//

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //Instantiate all of the rocks and cause them to
            // move from left to right, top to 
            // bottom. Pass a reference to the same Random
            // object to all of the sprites.
            for (int cnt = 0; cnt < numRocks; cnt++)
            {
                rocks.Add(new Sprite("Rock", Content, random));

                //Set the position of the current rock at a
                // random location within the game window.
                rocks[cnt].Position = new Vector2(
                   (float)(windowWidth * random.NextDouble()),
                   (float)(windowHeight * random.NextDouble()));

                //Get a direction vector for the current rock.
                // Make both components positive to cause the
                // vector to point down and to the right.
                rocks[cnt].Direction = DirectionVector(
                  (float)maxVectorLength,
                  (float)(maxVectorLength * random.NextDouble()),
                  false,//xNeg
                  false);//yNeg

                //Notify the Sprite object of the size of the
                // game window.
                rocks[cnt].WindowSize =
                             new Point(windowWidth, windowHeight);

                //Set the speed in moves per second for the
                // current sprite to a random value between
                // maxRockSpeed/2 and maxRockSpeed.
                rocks[cnt].Speed = maxRockSpeed / 2
                         + maxRockSpeed * random.NextDouble() / 2;
            }//end for loop

            //Use the same process to instantiate all of the
            // power pills and cause them to move from right
            // to left, top to bottom.
            for (int cnt = 0; cnt < numPills; cnt++)
            {
                pills.Add(new Sprite("ball", Content, random));
                pills[cnt].Position = new Vector2(
                    (float)(windowWidth * random.NextDouble()),
                    (float)(windowHeight * random.NextDouble()));
                pills[cnt].Direction = DirectionVector(
                  (float)maxVectorLength,
                  (float)(maxVectorLength * random.NextDouble()),
                  true,//xNeg
                  false);//yNeg
                pills[cnt].WindowSize =
                             new Point(windowWidth, windowHeight);
                pills[cnt].Speed = maxPillSpeed / 2
                          + maxPillSpeed * random.NextDouble() / 2;
            }//end for loop

            //Use the same process to instantiate all of the
            // ufos and cause them to move from right to left,
            // bottom to top.
            for (int cnt = 0; cnt < numUfos; cnt++)
            {
                ufos.Add(new Sprite("ufo", Content, random));
                ufos[cnt].Position = new Vector2(
                    (float)(windowWidth * random.NextDouble()),
                    (float)(windowHeight * random.NextDouble()));
                ufos[cnt].Direction = DirectionVector(
                 (float)maxVectorLength,
                 (float)(maxVectorLength * random.NextDouble()),
                 true,//xNeg
                 true);//yNeg
                ufos[cnt].WindowSize =
                             new Point(windowWidth, windowHeight);
                ufos[cnt].Speed = maxUfoSpeed / 2
                           + maxUfoSpeed * random.NextDouble() / 2;
            }//end for loop

        }//end LoadContent
        //-------------------------------------------------//

        //This method returns a direction vector given the
        // length of the vector, the length of the
        // X component, the sign of the X component, and the
        // sign of the Y component. Set negX and/or negY to
        // true to cause them to be negative. By adjusting
        // the signs on the X and Y components, the vector
        // can be caused to point into any of the four
        // quadrants.
        private Vector2 DirectionVector(float vecLen,
                                        float xLen,
                                        Boolean negX,
                                        Boolean negY)
        {
            Vector2 result = new Vector2(xLen, 0);
            result.Y = (float)Math.Sqrt(vecLen * vecLen
                                                 - xLen * xLen);
            if (negX)
                result.X = -result.X;
            if (negY)
                result.Y = -result.Y;
            return result;
        }//end DirectionVector
        //-------------------------------------------------//

        protected override void UnloadContent()
        {
            //No content unload required.
        }//end unloadContent
        //-------------------------------------------------//

        protected override void Update(GameTime gameTime)
        {
            //Tell all the rocks in the list to move.
            for (int cnt = 0; cnt < rocks.Count; cnt++)
            {
                rocks[cnt].Move(gameTime);
            }//end for loop

            //Tell all the power pills in the list to move.
            for (int cnt = 0; cnt < pills.Count; cnt++)
            {
                pills[cnt].Move(gameTime);
            }//end for loop

            //Tell all the ufos in the list to move.
            for (int cnt = 0; cnt < ufos.Count; cnt++)
            {
                ufos[cnt].Move(gameTime);
            }//end for loop

            base.Update(gameTime);
        }//end Update method
        //-------------------------------------------------//

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            //Draw all rocks.
            for (int cnt = 0; cnt < rocks.Count; cnt++)
            {
                rocks[cnt].Draw(spriteBatch);
            }//end for loop

            //Draw all power pills.
            for (int cnt = 0; cnt < pills.Count; cnt++)
            {
                pills[cnt].Draw(spriteBatch);
            }//end for loop

            //Draw all ufos.
            for (int cnt = 0; cnt < ufos.Count; cnt++)
            {
                ufos[cnt].Draw(spriteBatch);
            }//end for loop

            spriteBatch.End();

            base.Draw(gameTime);
        }//end Draw method
        //-------------------------------------------------//
    }//end class
}//end namespace


