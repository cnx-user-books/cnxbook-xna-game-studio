﻿/*Project Polymorph04
Copyright 2009, R.G.Baldwin

This program illustrates polymorphic behavior
and the Object class

Program output is:
  
A
ToString in class B
ToString in class C
*********************************************************/
using System;

class A : Object
{
    //This class is empty
}//end class A
//======================================================//

class B : A
{
    public override String ToString()
    {
        return "ToString in class B";
    }//end overridden ToString()
}//end class B
//======================================================//

class C : B
{
    public override String ToString()
    {
        return "ToString in class C";
    }//end overridden ToString()
}//end class B
//======================================================//

public class Polymorph04
{
    public static void Main()
    {
        Object varA = new A();
        String v1 = varA.ToString();
        Console.WriteLine(v1);

        Object varB = new B();
        String v2 = varB.ToString();
        Console.WriteLine(v2);

        Object varC = new C();
        String v3 = varC.ToString();
        Console.WriteLine(v3);

        //Pause until user presses any key.
        Console.ReadKey();
    }//end Main
}//end class Polymorph04
