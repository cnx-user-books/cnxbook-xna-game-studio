/*Project XNA0124Proj
 * Illustrates displaying a sprite with color key
 * transparency in front of a background image.
 * Must modify the color key property value for the ufo 
 * sprite, changing the key color from the default of
 * 255,0,255 (magenta or magic pink) to 0,255,0 (green).
 * The scale and the origin of the background image is
 * changed over time giving the illusion of a ufo 
 * flying over a planet.
********************************************************/

using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XNA0124Proj {

  public class Game1 : Microsoft.Xna.Framework.Game {
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;
    private Viewport viewport;
    private Vector2 ufoPosition;
    private float backgroundScale;
    private float backgroundBaseScale;
    private float dynamicScale = 0.0f;
    int msElapsed;//Time since last new frame.
    int msPerFrame = 83;//30 updates per second
    Texture2D spaceTexture;//background image
    Texture2D ufoTexture;//ufo image
    Vector2 spaceOrigin;//origin for drawing background

    public Game1() {//constructor
      graphics = new GraphicsDeviceManager(this);
      Content.RootDirectory = "Content";

      //Set the size of the game window, causing the
      // aspect ratio of the game window to match the 
      // aspect ratio of the background image, which is 
      // 640 wide by 480 high.
      graphics.PreferredBackBufferWidth = 450;
      graphics.PreferredBackBufferHeight = 
                                   (int)(450.0*480/640);
    }//end constructor
    //-------------------------------------------------//

    protected override void Initialize() {
      // No initialization required
      base.Initialize();
    }//end Initialize
    //-------------------------------------------------//

    protected override void LoadContent() {
      // Create a new SpriteBatch, which can be used to
      // draw textures.
      spriteBatch = new SpriteBatch(GraphicsDevice);

      //Load the two images.
      spaceTexture = Content.Load<Texture2D>("space");
      ufoTexture = Content.Load<Texture2D>("ufo");

      //Get a referebce to the viewport.
      viewport = graphics.GraphicsDevice.Viewport;

      //Compute the position of the ufo relative to the
      // game window.
      ufoPosition.X = viewport.Width / 2;
      ufoPosition.Y = viewport.Height - 70;

      //Set the backgroundBaseScale factor such that
      // the entire background image will fit in the
      // game window. Note that the aspect ratio of the
      // game window was set to match the aspect ratio 
      // of the background image in the constructor.
      backgroundBaseScale = (float)(450.0 / 640.0);
    }//end LoadContent
    //-------------------------------------------------//

    protected override void UnloadContent() {
      // No unload required
    }//end UnloadContent
    //-------------------------------------------------//

    protected override void Update(GameTime gameTime) {

      //Compute the elapsed time since the last update.
      // Draw new data only if this time exceeds the
      // desired frame interval given by msPerFrame
      msElapsed += gameTime.ElapsedGameTime.Milliseconds;
      if(msElapsed > msPerFrame) {
        //Reset the elapsed time and draw the frame with
        // new data.
        msElapsed = 0;

        //Reset the animation if the dynamicScale factor
        // is greater than 10.
        if(dynamicScale > 10) {
          dynamicScale = 0.0f;
        } else {
          //Increase the dynamicScale factor and use it
          // to compute a new scale factor that will be
          // applied to the background image in the next
          // call to the Draw method.
          dynamicScale += 0.03f;
          backgroundScale = 
                backgroundBaseScale * (1 + dynamicScale);
        }//end if-else on dynamicScale

        //Also use the dynamicScale factor to compute a
        // new value for the origin of the background.
        // The origin is the point in the image that is
        // drawn at the point in the game window that is
        // passed as the second (position) parameter in
        // the call to the SpriteBatch.Draw method. This
        // has the effect of causing the background
        // image to slide up and to the left at the same
        // time that it is getting larger.
        spaceOrigin = 
          new Vector2((float)(450 * (dynamicScale) / 12),
                     (float)(338 * (dynamicScale) / 10));
      }//end if on msElapsed

      base.Update(gameTime);
    }//end Update
    //-------------------------------------------------//

    protected override void Draw(GameTime gameTime) {

      // Turn off blending to draw the planet in the
      // background.
      spriteBatch.Begin(SpriteBlendMode.None);

      //Draw the background.
      spriteBatch.Draw(spaceTexture,//sprite
                       Vector2.Zero,//position re window
                       null,//rectangle
                       Color.White,//tint
                       0,//rotation
                       spaceOrigin,//origin
                       backgroundScale,//scale
                       SpriteEffects.None,
                       1.0f);//layer, near the back

      spriteBatch.End();

      // Turn on blending to draw the UFO in the 
      // foreground.
      spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
      //Center the UFO at the point in the window
      // identified as UFO position. The UFO image is
      // 64x33 pixels.
      Vector2 origin = new Vector2(32,16);
      spriteBatch.Draw(ufoTexture,//sprite
                       ufoPosition,//position re window
                       null,//rectangle
                       Color.White,//tine
                       0,//rotation
                       origin,//origin
                       1,//scale
                       SpriteEffects.None,
                       0f);//layer, 0 is in front

      spriteBatch.End();

      base.Draw(gameTime);
    }//end Draw method
  }//end class
}//end namespace
