/*Project XNA0130Proj
 * This project demonstrates how to integrate  
 * spiders, and ladybugs in a program using
 * objects of a Sprite class with collision
 * detection.
 * *****************************************************/
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using XNA0130Proj;

namespace XNA0130Proj {

  public class Game1 : Microsoft.Xna.Framework.Game {
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;

    //Use the following values to set the size of the
    // client area of the game window. The actual window
    // with its frame is somewhat larger depending on
    // the OS display options. On my machine with its
    // current display options, these dimensions
    // produce a 1024x768 game window.
    int windowWidth = 1017;
    int windowHeight = 738;

    //This is the length of the greatest distance in
    // pixels that any sprite will move in a single
    // frame of the game loop.
    double maxVectorLength = 5.0;

    Sprite spiderWeb;//reference to a background sprite.

    //References to the spiders are stored in this
    // List object.
    List<Sprite> spiders = new List<Sprite>();
    int numSpiders = 200;//Number of spiders.
    //The following value should never exceed 60 moves
    // per second unless the default frame rate is also
    // increased to more than 60 frames per second.
    double maxSpiderSpeed = 30;//moves per second

    //References to the Ladybugs are stored in this List.
    List<Sprite> ladybugs = new List<Sprite>();
    int numLadybugs = 5;//Max number of ladybugs
    double maxLadybugSpeed = 15;

    //Random number generator. It is best to use a single
    // object of the Random class to avoid the 
    // possibility of using different streams that
    // produce the same sequence of values.
    //Note that the random.NextDouble() method produces
    // a pseudo-random value where the sequence of values
    // is uniformly distributed between 0.0 and 1.0.
    Random random = new Random();
    //-------------------------------------------------//

    public Game1() {//constructor
      graphics = new GraphicsDeviceManager(this);
      Content.RootDirectory = "Content";

      //Set the size of the game window.
      graphics.PreferredBackBufferWidth = windowWidth;
      graphics.PreferredBackBufferHeight = windowHeight;
    }//end constructor
    //-------------------------------------------------//

    protected override void Initialize() {
      //No initialization required.
      base.Initialize();
    }//end Initialize
    //-------------------------------------------------//

    protected override void LoadContent() {
      spriteBatch = new SpriteBatch(GraphicsDevice);

      //Create a sprite for the background image.
      spiderWeb = 
                 new Sprite("spiderwebB",Content,random);
      spiderWeb.Position = new Vector2(0f,0f);


      //Instantiate all of the spiders and cause them to
      // move from left to right, top to 
      // bottom. Pass a reference to the same Random
      // object to all of the sprites.
      for(int cnt = 0;cnt < numSpiders;cnt++) {
        spiders.Add(
          new Sprite("blackWidowSpider",Content,random));

        //Set the position of the current spider at a
        // random location within the game window.
        spiders[cnt].Position = new Vector2(
           (float)(windowWidth * random.NextDouble()),
           (float)(windowHeight * random.NextDouble()));

        //Get a direction vector for the current spider.
        // Make both components positive to cause the
        // vector to point down and to the right.
        spiders[cnt].Direction = DirectionVector(
          (float)maxVectorLength,
          (float)(maxVectorLength * random.NextDouble()),
          false,//xNeg
          false);//yNeg

        //Notify the spider object of the size of the
        // game window.
        spiders[cnt].WindowSize =
                     new Point(windowWidth,windowHeight);

        //Set the speed in moves per second for the
        // current spider to a random value between
        // maxSpiderSpeed/2 and maxSpiderSpeed.
        spiders[cnt].Speed = maxSpiderSpeed / 2
              + maxSpiderSpeed * random.NextDouble() / 2;
      }//end for loop

      //Use the same process to instantiate all of the
      // ladybugs and cause them to move from right to
      // left, bottom to top.
      for(int cnt = 0;cnt < numLadybugs;cnt++) {
        ladybugs.Add(
                   new Sprite("ladybug",Content,random));
        ladybugs[cnt].Position = new Vector2(
            (float)(windowWidth * random.NextDouble()),
            (float)(windowHeight * random.NextDouble()));
        ladybugs[cnt].Direction = DirectionVector(
         (float)maxVectorLength,
         (float)(maxVectorLength * random.NextDouble()),
         true,//xNeg
         true);//yNeg
        ladybugs[cnt].WindowSize =
                     new Point(windowWidth,windowHeight);
        ladybugs[cnt].Speed = maxLadybugSpeed / 2
             + maxLadybugSpeed * random.NextDouble() / 2;
      }//end for loop

    }//end LoadContent
    //-------------------------------------------------//

    //This method returns a direction vector given the
    // length of the vector, the length of the
    // X component, the sign of the X component, and the
    // sign of the Y component. Set negX and/or negY to
    // true to cause them to be negative. By adjusting
    // the signs on the X and Y components, the vector
    // can be caused to point into any of the four
    // quadrants.
    private Vector2 DirectionVector(float vecLen,
                                    float xLen,
                                    Boolean negX,
                                    Boolean negY) {
      Vector2 result = new Vector2(xLen,0);
      result.Y = (float)Math.Sqrt(vecLen * vecLen
                                          - xLen * xLen);
      if(negX)
        result.X = -result.X;
      if(negY)
        result.Y = -result.Y;
      return result;
    }//end DirectionVector
    //-------------------------------------------------//

    protected override void UnloadContent() {
      //No content unload required.
    }//end unloadContent
    //-------------------------------------------------//

    protected override void Update(GameTime gameTime) {
      //Tell all the spiders in the list to move.
      for(int cnt = 0;cnt < spiders.Count;cnt++) {
        spiders[cnt].Move(gameTime);
      }//end for loop

      //Tell all the ladybugs in the list to move.
      for(int cnt = 0;cnt < ladybugs.Count;cnt++) {
        ladybugs[cnt].Move(gameTime);
      }//end for loop

      //Tell each ladybug to test for a collission with a
      // spider and to return a reference to the spider
      // if there is a collision. Return null if there is
      // no collision.
      for(int cnt = 0;cnt < ladybugs.Count;cnt++) {

        //Test for a collision between this ladybug and
        // all of the spiders in the list of spiders.
        Sprite target = 
                      ladybugs[cnt].IsCollision(spiders);
        if(target != null) {
          //There was a collision. Cause the spider to
          // move 128 pixels to the right.
          target.Position = 
                    new Vector2(target.Position.X + 128,
                                target.Position.Y);

          //If the collision was with a black widow
          // spider, cause it to reincarnate into a
          // green spider.
          if(target.Image.Name == "blackWidowSpider") {
            target.SetImage("greenspider",Content);
          }//If the collision was with a green spider,
           // cause it to reincarnate into a brown
           // spider.
          else if(target.Image.Name == "greenspider") {
            target.SetImage("brownSpider",Content);
          }//If the collision was with a brown spider,
           // it gets eaten. Remove it from the list of
           // spiders.
          else if(target.Image.Name == "brownSpider") {
            spiders.Remove(target);
          }// end else-if
        }//end if
      }//end for loop

      base.Update(gameTime);
    }//end Update method
    //-------------------------------------------------//

    protected override void Draw(GameTime gameTime) {

      spriteBatch.Begin();

      spiderWeb.Draw(spriteBatch);//draw background 

      //Draw all spiders.
      for(int cnt = 0;cnt < spiders.Count;cnt++) {
        spiders[cnt].Draw(spriteBatch);
      }//end for loop

      //Draw all ladybugs.
      for(int cnt = 0;cnt < ladybugs.Count;cnt++) {
        ladybugs[cnt].Draw(spriteBatch);
      }//end for loop

      spriteBatch.End();

      base.Draw(gameTime);
    }//end Draw method
    //-------------------------------------------------//
  }//end class
}//end namespace