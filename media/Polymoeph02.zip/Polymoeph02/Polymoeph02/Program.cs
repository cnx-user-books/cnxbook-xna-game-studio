﻿/*Project Polymorph02
Copyright 2002, R.G.Baldwin

This program illustrates downcasting
Program output is:
m in class B
*********************************************************/
using System;

class A
{
    //this class is empty
}//end class A
//======================================================//

class B : A
{
    public void m()
    {
        Console.WriteLine("m in class B");
    }//end method m()
}//end class B
//======================================================//

class C
{
    //this class is empty
}//end class C
//======================================================//

public class Polymorph02
{
    public static void Main()
    {
        Object var = new B();
        //Following will not compile
        //var.m();
        //Following will not compile
        //((A)var).m();    
        //Following will compile and run
        ((B)var).m();

        //Following will compile and run
        B v1 = (B)var;
        //Following will not execute.
        // Causes a runtime exception.
        //C v2 = (C)var;
        //Following will not compile
        //C v3 = (B)var;

        //Pause until user presses any key.
        Console.ReadKey();
    }//end Main
}//end class Polymorph02
//======================================================/
