﻿/*Project XNA0132Proj
 * This file defines a Sprite class from which a Sprite
 * object can be instantiated. This version supports
 * collision detection based on intersecting rectangles.
 * It also provides an Edge property that records and
 * returns the edge number if a sprite collides with an
 * edge. However, the edge information is available for
 * only one iteration of the game loop. Normally the
 * value of Edge is 0. However, it changes to 1,2,3,or4
 * if a sprite collides with the top, right, bottom, or
 * left edge of the game window.
 *******************************************************/

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace XNA0132Proj
{
    class Sprite
    {
        private int edge = 0;//new to this version
        private Texture2D image;
        private Vector2 position = new Vector2(0, 0);
        private Vector2 direction = new Vector2(0, 0);
        private Point windowSize;
        private Random random;
        double elapsedTime;//in milliseconds
        //The following value is the inverse of speed in
        // moves/msec expressed in msec/move.
        double elapsedTimeTarget;
        //-------------------------------------------------//

        //New to this version.
        //Edge property accessor
        public int Edge
        {
            get
            {
                return edge;
            }//end get
        }//end Edge property accessor
        //-------------------------------------------------//

        //Image property accessor
        public Texture2D Image
        {
            get
            {
                return image;
            }//end get
        }//end Image property accessor
        //-------------------------------------------------//

        //Position property accessor
        public Vector2 Position
        {
            get
            {
                return position;
            }
            set
            {
                position = value;
            }//end set
        }//end Position property accessor
        //-------------------------------------------------//

        //WindowSize property accessor
        public Point WindowSize
        {
            set
            {
                windowSize = value;
            }//end set
        }//end WindowSize property accessor
        //-------------------------------------------------//

        //Direction property accessor
        public Vector2 Direction
        {
            get
            {
                return direction;
            }
            set
            {
                direction = value;
            }//end set
        }//end Direction property accessor

        //-------------------------------------------------//

        //Speed property accessor. The set side should be
        // called with speed in moves/msec. The get side
        // returns speed moves/msec.
        public double Speed
        {
            get
            {
                //Convert from elapsed time in msec/move to
                // speed in moves/msec.
                return elapsedTimeTarget / 1000;
            }
            set
            {
                //Convert from speed in moves/msec to
                // elapsed time in msec/move.
                elapsedTimeTarget = 1000 / value;
            }//end set
        }//end Speed property accessor
        //-------------------------------------------------//

        //This constructor loads an image for the sprite
        // when it is instantiated. Therefore, it requires
        // an asset name for the image and a reference to a
        // ContentManager object.
        //Requires a reference to a Random object. Should 
        // use the same Random object for all sprites to
        // avoid getting the same sequence for different
        // sprites.
        public Sprite(String assetName,
                      ContentManager contentManager,
                      Random random)
        {
            image = contentManager.Load<Texture2D>(assetName);
            image.Name = assetName;
            this.random = random;
        }//end constructor
        //-------------------------------------------------//

        //This method can be called to load a new image
        // for the sprite.
        public void SetImage(String assetName,
                             ContentManager contentManager)
        {
            image = contentManager.Load<Texture2D>(assetName);
            image.Name = assetName;
        }//end SetImage
        //-------------------------------------------------//

        //This method causes the sprite to move in the 
        // direction of the direction vector if the elapsed
        // time since the last move exceeds the elapsed
        // time target based on the specified speed.
        public void Move(GameTime gameTime)
        {

            //New to this version
            //Clear the Edge property value. Edge information
            // is available for only one iteration of the 
            // game loop.
            edge = 0;

            //Accumulate elapsed time since the last move.
            elapsedTime +=
                        gameTime.ElapsedGameTime.Milliseconds;

            if (elapsedTime > elapsedTimeTarget)
            {
                //It's time to make a move. Set the elapsed 
                // time to a value that will attempt to produce
                // the specified speed on the average.
                elapsedTime -= elapsedTimeTarget;

                //Add the direction vector to the position
                // vector to get a new position vector.
                position = Vector2.Add(position, direction);

                //Check for a collision with an edge of the game
                // window. If the sprite reaches an edge, cause 
                // the sprite to wrap around and reappear at the 
                // other edge, moving at the same speed in a 
                // different direction within the same quadrant 
                // as before. Also set the Edge property to
                // indicate which edge was involved. 1 is top, 2
                // is right, 3 is bottom, and 4 is left.
                // Note that the Edge property will be cleared
                // to 0 the next time the Move method is called.
                if (position.X < -image.Width)
                {
                    position.X = windowSize.X;
                    edge = 4;//collision with the left edge - new
                    NewDirection();
                }//end if

                if (position.X > windowSize.X)
                {
                    position.X = -image.Width / 2;
                    edge = 2;//collision with the right edge - new
                    NewDirection();
                }//end if

                if (position.Y < -image.Height)
                {
                    position.Y = windowSize.Y;
                    edge = 1;//collision with the top - new
                    NewDirection();
                }//end if

                if (position.Y > windowSize.Y)
                {
                    position.Y = -image.Height / 2;
                    edge = 3;//collision with the bottom - new
                    NewDirection();
                }//end if on position.Y
            }//end if on elapsed time
        }//end Move
        //-------------------------------------------------//

        //This method determines the length of the current 
        // direction vector along with the signs of the X 
        // and Y components of the current direction vector.
        // It computes a new direction vector of the same 
        // length with the X and Y components having random
        // lengths and the same signs.
        //Note that random.NextDouble returns a 
        // pseudo-random value, uniformly distrubuted
        // between 0.0 and 1.0.
        private void NewDirection()
        {
            //Get information about the current direction
            // vector.
            double length = Math.Sqrt(
                                  direction.X * direction.X +
                                  direction.Y * direction.Y);
            Boolean xNegative =
                              (direction.X < 0) ? true : false;
            Boolean yNegative =
                              (direction.Y < 0) ? true : false;

            //Compute a new X component as a random portion of
            // the vector length.
            direction.X =
                        (float)(length * random.NextDouble());
            //Compute a corresponding Y component that will 
            // keep the same vector length.
            direction.Y = (float)Math.Sqrt(length * length -
                                    direction.X * direction.X);

            //Set the signs on the X and Y components to match
            // the signs from the original direction vector.
            if (xNegative)
                direction.X = -direction.X;
            if (yNegative)
                direction.Y = -direction.Y;
        }//end NewDirection
        //-------------------------------------------------//

        public void Draw(SpriteBatch spriteBatch)
        {
            //Call the simplest available version of
            // SpriteBatch.Draw
            spriteBatch.Draw(image, position, Color.White);
        }//end Draw method
        //-------------------------------------------------//

        //Returns the current rectangle occupied by the
        // sprite.
        public Rectangle GetRectangle()
        {
            return new Rectangle((int)(position.X),
                                 (int)(position.Y),
                                 image.Width,
                                 image.Height);
        }//end GetRectangle
        //-------------------------------------------------//

        //This method receives a list of Sprite objects as
        // an incoming parameter. It tests for a collision
        // with the sprites in the list beginning with the
        // sprite at the head of the list. If it detects a
        // collision, it stops testing immediately and
        // returns a reference to the Sprite object for
        // which it found the collision. If it doesn't find
        // a collision with any sprite in the list, it
        // returns null.
        //A collision is called if the rectangle containing
        // this object's image intersects the rectangle
        // containing a target sprite's image.
        public Sprite IsCollision(List<Sprite> target)
        {
            Rectangle thisRectangle =
                               new Rectangle((int)(position.X),
                                             (int)(position.Y),
                                             image.Width,
                                             image.Height);
            Rectangle targetRectangle;
            int cnt = 0;

            while (cnt < target.Count)
            {
                targetRectangle = target[cnt].GetRectangle();
                if (thisRectangle.Intersects(targetRectangle))
                {
                    return target[cnt];
                }//end if
                cnt++;
            }//end while loop

            return null;//no collision detected
        }//end IsCollision
        //-------------------------------------------------//

    }//end class
}//end namespace