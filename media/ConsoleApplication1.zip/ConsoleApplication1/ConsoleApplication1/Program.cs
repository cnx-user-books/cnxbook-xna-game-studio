﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hello01
{
    class Hello01
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello C# World");
            //Press any key to dismiss console screen.
            Console.ReadKey();
        }//end Main
    }//end class
}//end namespace
