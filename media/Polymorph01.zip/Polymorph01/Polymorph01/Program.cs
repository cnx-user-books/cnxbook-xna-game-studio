﻿/*Project Polymorph01
Copyright 2009, R.G.Baldwin

This program illustrates method
overloading, both within a class, and
up the inheritance hierarchy.

Program output is:
  
m()
m(int x)
m(String y)
**************************************/
using System;

class A : Object
{
    public void m()
    {
        Console.WriteLine("m()");
    }//end method m()
}//end class A
//===================================//

class B : A
{
    public void m(int x)
    {
        Console.WriteLine("m(int x)");
    }//end method m(int x)
    //---------------------------------//

    public void m(String y)
    {
        Console.WriteLine("m(String y)");
    }//end method m(String y)
}//end class B
//===================================//

public class Polymorph01
{
    public static void Main()
    {
        B var = new B();
        var.m();
        var.m(3);
        var.m("String");

        //Pause until the user presses
        // a key.
        Console.ReadKey();
    }//end Main

}//end class Polymorph01
