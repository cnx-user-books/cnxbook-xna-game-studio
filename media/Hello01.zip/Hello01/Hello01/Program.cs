﻿//File Program.cs
using System;
namespace Hello01
{

    class Hello01
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Hello C# World");
            //Press any key to dismiss console screen.
            Console.ReadKey();
        }//end Main

    }//end class definition

}//end namespace
